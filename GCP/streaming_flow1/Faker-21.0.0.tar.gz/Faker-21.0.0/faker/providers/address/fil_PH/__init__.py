from ..en_PH import Provider as EnPhAddressProvider


class Provider(EnPhAddressProvider):
    """No difference from Address Provider for en_PH locale"""

    pass
