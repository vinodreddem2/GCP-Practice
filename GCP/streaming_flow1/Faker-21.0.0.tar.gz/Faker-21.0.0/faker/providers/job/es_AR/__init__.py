from ..es import Provider as BaseProvider


class Provider(BaseProvider):
    pass
